angular.module('myva', ['ngMaterial', 'ngRoute', 'ngResource', 'ngMessages'])
.config(function ($routeProvider) {
    $routeProvider
     .when('/Lists', {
         templateUrl: domain + 'Lists',
         controller: 'ListsCtrl'
     })
    .when('/ListEdit/:id', {
        templateUrl: domain + 'ListEdit',
        controller: 'ListEditCtrl'
    })
    .when('/List/:id', {
        templateUrl: domain + 'Lists',
        controller: 'ListCtrl'
    })
    .otherwise({
        redirectTo: '/Lists'
    });
})
.directive('mvDatefilter', function ($mdDialog, $timeout) {
    return {
        require: '?ngModel',
        link: function (scope, element, attr, ngModelCtrl) {
            element.next('md-datepicker').find('.md-datepicker-button').hide();
            debugger;
            element.append();
            scope.$watch(attr.ngModel, function (value) {
                if (value) {
                    var icon = element.find('md-icon');
                    var title = $('<span class="mv-filtertitle" style="display:none"></span>');
                    element.find('.mv-filtertitle').remove();
                    if (value.mainDate && value.addDate) {
                        var duration = moment(value.addDate).diff(moment(value.mainDate), 'days');
                        element.append('<span class="mv-filtertitle" ' + (duration > 0 ? '' : 'style="color:red"') + ' >' + (duration > 0 ? '+' + duration : '0') + '</span>');
                        icon.hide();
                    } else if (value.mainDate && (value.infnt > 0 || value.infnt < 0)) {
                        element.append('<span class="mv-filtertitle">' + (value.infnt > 0 ? '+' : '-') + '</span>');
                        icon.hide();
                    } else {
                        icon.show();
                    }
                }
            }, true);
            element.on('click', function () {
                $mdDialog.show({
                    parent: angular.element(document.body),
                    template:
                      '<md-dialog aria-label="List dialog">' +
                      '  <md-dialog-content>' +
                      '    <md-list>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="today()">Today</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="yesterday()">Yesterday</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="thisweek()">This week</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="previousweek()">Previous week</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="thismonth()">This month</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="previousmonth()">Previous month</md-button>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-datepicker ng-model="from" md-placeholder="From..."></md-datepicker><md-datepicker ng-model="to" md-placeholder="Until..."></md-datepicker>' +
                      '    </md-list-item>' +
                      '      <md-list-item>' +
                      '       <md-button flex ng-click="clear()">Clear</md-button>' +
                      '    </md-list-item>' +
                      '</md-list>' +
                      '  </md-dialog-content>' +
                      '  <md-dialog-actions>' +
                      '    <md-button ng-click="ok()" class="md-primary">' +
                      '      OK' +
                      '    </md-button>' +
                      '    <md-button ng-click="close()" class="md-primary">' +
                      '      Close' +
                      '    </md-button>' +
                      '  </md-dialog-actions>' +
                      '</md-dialog>',
                    controller: DialogController
                });
                function DialogController($scope, $mdDialog) {
                    var dt = ngModelCtrl.$viewValue;
                    if (dt && dt.mainDate) {
                        if (dt.addDate) {
                            $scope.from = dt.mainDate;
                            $scope.to = dt.addDate;
                        } else if (dt.infnt > 0) {
                            $scope.from = dt.mainDate;
                        } else if (dt.infnt < 0) {
                            $scope.to = dt.mainDate;
                        }
                    }

                    $scope.close = function () {
                        $mdDialog.hide();
                    }
                    $scope.ok = function () {
                        var dt = {};
                        if ($scope.from && $scope.to) {
                            dt.mainDate = $scope.from;
                            //  var duration = moment($scope.to).diff(moment($scope.from), 'days');
                            dt.addDate = $scope.to;
                        } else if ($scope.from) {
                            dt.mainDate = $scope.from;
                            dt.infnt = 1;
                        } else if ($scope.to) {
                            dt.mainDate = $scope.to;
                            dt.infnt = -1;
                        }
                        ngModelCtrl.$setViewValue(dt);
                        $mdDialog.hide();
                    }
                    $scope.today = function () {
                        var td = moment();
                        $scope.from = td.toDate();
                        $scope.to = moment(td).add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.yesterday = function () {
                        var td = moment().subtract(1, 'day');
                        $scope.from = td.toDate();
                        $scope.to = moment(td).add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.thisweek = function () {
                        var td = moment();
                        $scope.from = td.startOf('week').toDate();
                        $scope.to = moment(td).endOf('week').add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.previousweek = function () {
                        var td = moment().subtract(7, 'day');
                        $scope.from = td.startOf('week').toDate();
                        $scope.to = moment(td).endOf('week').add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.thismonth = function () {
                        var td = moment();
                        $scope.from = td.startOf('month').toDate();
                        $scope.to = moment(td).endOf('month').add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.previousmonth = function () {
                        var td = moment().subtract(1, 'month');
                        $scope.from = td.startOf('month').toDate();
                        $scope.to = moment(td).endOf('month').add(1, 'day').toDate();
                        $scope.ok();
                    }
                    $scope.clear = function () {
                        $scope.from = null;
                        $scope.to = null;
                        $scope.ok();
                    }
                }
            });
        }

    };
})
//.provider('$mvFilter2', function ($$interimElementProvider) {
//    debugger;
//    return {
//        setFilter: function () {
//            debugger;
//        }
//    };
//})
.factory('$mvFilter', ["$mdDialog", "$rootScope", function ($mdDialog, $rootScope) {
    return {
        setFilter: function (dt) {
            var sss = $rootScope;
            //dt.from = new Date();
            debugger;
            var parentEl = angular.element(document.body);
            $mdDialog.show({
                parent: parentEl,
                // targetEvent: $event,
                template:
                  '<md-dialog aria-label="List dialog">' +
                  '  <md-dialog-content>' +
                  '    <md-list>' +
                  '      <md-list-item ng-repeat="item in items">' +
                  '       <p>Number {{item}}</p>' +
                  '      ' +
                  '    </md-list-item></md-list>' +
                  '  </md-dialog-content>' +
                  '  <md-dialog-actions>' +
                  '<md-datepicker ng-model="myDate" md-placeholder="Enter date"></md-datepicker>' +
                  '    <md-button ng-click="closeDialog()" class="md-primary">' +
                  '      Close Dialog' +
                  '    </md-button>' +
                  '  </md-dialog-actions>' +
                  '</md-dialog>',
                controller: DialogController
            });
            function DialogController($scope, $mdDialog) {
                //  $scope.items = items;
                $scope.closeDialog = function () {
                    alert($scope.myDate);
                    $mdDialog.hide();
                }
            }
        }
    };
}])
.controller('LoadCtrl', function ($rootScope, $scope, $mvFilter) {
   
    $rootScope.test = $mvFilter.setFilter;
})
.controller('ListsCtrl', function ($rootScope, $scope, $location) {
    $scope.lists = [{ Id: 1, Title: 'Myva applications' }, { Id: 2, Title: 'Demo applications' }, { Id: 3, Title: 'My first form' }];
    $scope.open = function (id) {
        // $location.url("/ListEdit/" + id);
    }
    $scope.edit = function (id) {
        $location.url("/ListEdit/" + id);
    }
    $scope.new = function (id) {
        if ($scope.newlist.$valid) {
            $scope.lists.push({ Id: 4, Title: $scope.title });
            $location.url("/ListEdit/" + 4);
        }
    }
})
.controller('ListEditCtrl', function ($scope, $timeout, $mdSidenav, $mdDialog) {
    $scope.project = {};
    function MvItem(type) {
        this.Type = type;
        this.Title = '';
        this.Options = [];
        this.IsRequired = false;
    }
    MvItem.prototype.removeOption = function (option) {
        var item = this;
        var confirm = $mdDialog.confirm()
                  .title('Are you sure?')
                  .textContent('All related data also would be removed.')
                  .ok('OK')
                  .cancel('Cancel');
        $mdDialog.show(confirm).then(function () {
            item.Options.splice(item.Options.indexOf(option), 1);
        });
    };
    MvItem.prototype.addOption = function () {
        if (this.$option) {
            this.Options.push({Title: this.$option});
            this.$option = '';
        }
    };

    $scope.tabIndex = 0;
    $scope.items = [];
    $scope.add = function (type) {
        var item = new MvItem(type);
        $scope.items.push(item);
        $scope.current = item;
        $scope.tabIndex = 1;
    }
    $scope.sortUp = function (item) {
        var index = $scope.items.indexOf(item);
        if (index > 0) {
            $scope.items.splice(index, 1);
            $scope.items.splice(index - 1, 0, item);
        }
    }
    $scope.sortDown = function (item) {
        var index = $scope.items.indexOf(item);
        if (index < $scope.items.length - 1) {
            $scope.items.splice(index, 1);
            $scope.items.splice(index + 1, 0, item);
        }
    }
    $scope.remove = function () {
        var confirm = $mdDialog.confirm()
                  .title('Are you sure?')
                  .textContent('All related data also would be removed.')
                  .ok('OK')
                  .cancel('Cancel');
        $mdDialog.show(confirm).then(function () {
            $scope.items.splice($scope.items.indexOf($scope.current), 1);
            $scope.current = null;
        });
    }
    /**
     * Supplies a function that will continue to operate until the
     * time is up.
     */
    function debounce(func, wait, context) {
        var timer;
        return function debounced() {
            var context = $scope,
                args = Array.prototype.slice.call(arguments);
            $timeout.cancel(timer);
            timer = $timeout(function () {
                timer = undefined;
                func.apply(context, args);
            }, wait || 10);
        };
    }
    /**
     * Build handler to open/close a SideNav; when animation finishes
     * report completion in console
     */
    function buildDelayedToggler(navID) {
        return debounce(function () {
            $mdSidenav(navID)
              .toggle()
              .then(function () {
                  $log.debug("toggle " + navID + " is done");
              });
        }, 200);
    }
    function buildToggler(navID) {
        return function () {
            $mdSidenav(navID)
              .toggle()
              .then(function () {
                  $log.debug("toggle " + navID + " is done");
              });
        }
    }
}).controller('LeftCtrl', function ($scope, $timeout, $mdSidenav, $log) {
    $scope.close = function () {
        $mdSidenav('left').close()
          .then(function () {
              $log.debug("close LEFT is done");
          });
    };
})
  .controller('RightCtrl', function ($scope, $timeout, $mdSidenav, $log) {
      $scope.close = function () {
          $mdSidenav('right').close()
            .then(function () {
                $log.debug("close RIGHT is done");
            });
      };
  });